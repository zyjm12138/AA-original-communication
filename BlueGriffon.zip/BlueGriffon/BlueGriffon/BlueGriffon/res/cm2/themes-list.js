const kTHEMES = [
"cobalt",
"eclipse",
"elegant",
"light",
"monokai",
"neat",
"night",
"rubyblue"
];
