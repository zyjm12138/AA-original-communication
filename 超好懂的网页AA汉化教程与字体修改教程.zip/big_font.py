import re
import os
import sys

f1 = open(str(sys.argv[1])+'.xhtml', 'r+', encoding='utf-8')
f2 = open(str(sys.argv[1])+'_big.xhtml', 'w+', encoding='utf-8')

str1 = r'@@'
str2 = r'<span style="font-size: 20px;font-family: JOJOHOTYuan-v1.1;line-height: 0;">'
str3 = r'##'
str4 = r'</span>'
for ss in f1.readlines():
    temp1 = re.sub(str1, str2, ss)
    temp2 = re.sub(str3, str4, temp1)
    f2.write(temp2)
f1.close()
f2.close()
